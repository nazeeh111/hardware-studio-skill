"""Serve Hardware Studio locally with a same-origin, loopback-only tray CAD API.

Run from the repository root:
    sh tools/tray-generator/run-local.sh --port 4174
"""

import argparse
import base64
import binascii
import io
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import threading
import zipfile
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

sys.dont_write_bytecode = True

import OCP  # Fail at startup if the CAD runtime is unavailable.
try:
    import build123d
    CURVED_RUNTIME = True
except ImportError:
    CURVED_RUNTIME = False

ROOT = Path(__file__).resolve().parents[2]
GENERATOR = Path(__file__).with_name('generate.py')
FIT = Path(__file__).with_name('fit.py')
SOLID_GENERATOR = Path(__file__).resolve().parents[1] / 'solid-generator' / 'solid.py'
ASSEMBLY_GENERATOR = Path(__file__).resolve().parents[1] / 'assembly-generator' / 'assembly.py'
PROJECT_GENERATOR = Path(__file__).resolve().parents[1] / 'project-generator' / 'project.py'
MAX_REQUEST_BYTES = 65_536
MAX_ASSEMBLY_REQUEST_BYTES = 262_144
MAX_PROJECT_REQUEST_BYTES = 17 * 1024 * 1024
MAX_FIT_REQUEST_BYTES = 24_000_000
MAX_STEP_BYTES = 8_000_000
PACKAGE_FILES = ('spec.json', 'tray.step', 'tray.stl', 'layout.svg', 'build-report.json', 'verification.json')
build_lock = threading.Lock()


def generate_package(raw, preview=False):
    """Run the existing verifier-backed CLI in an isolated temporary directory."""
    with tempfile.TemporaryDirectory(prefix='hardware-studio-cad-') as temporary:
        temporary = Path(temporary)
        source = temporary / 'input.json'
        source.write_bytes(raw)
        package = temporary / 'package'
        result = subprocess.run(
            [sys.executable, str(GENERATOR), '--spec', str(source), '--out', str(package)],
            capture_output=True, text=True, timeout=120,
        )
        if result.returncode:
            raise ValueError('The CAD generator rejected this geometry. Check dimensions, boss spacing and openings.')
        extras = ('lid.step', 'lid.stl') if (package / 'lid.step').is_file() and (package / 'lid.stl').is_file() else ()
        if preview:
            verification = json.loads((package / 'verification.json').read_text())
            names = ['tray.stl'] + (['lid.stl'] if extras else [])
            if sum((package / name).stat().st_size for name in names) > 16_000_000 or verification['stl_triangles'] + (verification.get('lid') or {}).get('stl_triangles', 0) > 400_000:
                raise ValueError('This preview exceeds the browser mesh limit. Download the CAD package instead.')
            return {'schema': 'hardware-studio-cad-preview-v1',
                    'spec': json.loads((package / 'spec.json').read_text()),
                    'verification': verification,
                    'meshes': [{'name': name, 'dataBase64': base64.b64encode((package / name).read_bytes()).decode('ascii')} for name in names]}
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
            for name in PACKAGE_FILES + extras:
                zipped.write(package / name, arcname=name)
        return archive.getvalue()



def generate_solid_package(raw, preview=False):
    """Build a bounded declarative feature model; never execute submitted code."""
    with tempfile.TemporaryDirectory(prefix='hardware-studio-solid-') as temporary:
        root = Path(temporary)
        source = root / 'input.json'
        source.write_bytes(raw)
        package = root / 'package'
        result = run_assembly_process([sys.executable, str(SOLID_GENERATOR), '--spec', str(source), '--out', str(package)], timeout=120)
        if result.returncode:
            message = 'Solid generation rejected the input or a geometry check. Each feature must affect one connected solid and all material/void probes must pass.'
            try:
                domain_error = json.loads(result.stderr.strip().splitlines()[-1]).get('error')
                if isinstance(domain_error, str) and domain_error:
                    message = domain_error[:1000]
            except (ValueError, IndexError, AttributeError):
                pass
            raise ValueError(message)
        files = ('spec.json', 'solid.step', 'solid.stl', 'build-report.json', 'verification.json')
        if (package / 'solid.raw.stl').is_file():
            files += ('solid.raw.stl',)
        if preview:
            report = json.loads((package / 'verification.json').read_text())
            mesh = (package / 'solid.stl').read_bytes()
            if len(mesh) > 16_000_000 or report['stl_triangles'] > 400_000:
                raise ValueError('The generated mesh exceeds the browser preview limit.')
            return {'schema': 'hardware-studio-solid-preview-v1', 'spec': json.loads((package / 'spec.json').read_text()), 'verification': report,
                    'meshes': [{'name': 'solid.stl', 'dataBase64': base64.b64encode(mesh).decode('ascii')}]}
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
            for name in files:
                zipped.write(package / name, arcname=name)
        return archive.getvalue()


def run_assembly_process(command, timeout=180):
    """Keep the generator and its verifier within one supervised POSIX group."""
    process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               text=True, start_new_session=True)
    try:
        stdout, stderr = process.communicate(timeout=timeout)
        return subprocess.CompletedProcess(command, process.returncode, stdout, stderr)
    finally:
        # Killing only the direct child leaves its fresh-process verifier alive,
        # possibly writing files after temporary cleanup and lock release. The
        # group remains addressable even if the generator exited first. Also
        # stop descendants on normal/nonzero exit when their pipes are closed.
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.communicate()


def generate_project_package(raw):
    request = json.loads(raw)
    if set(request) != {'schema', 'sourceZipBase64'} or not isinstance(request['sourceZipBase64'], str):
        raise ValueError('Send only the project package schema and captured source ZIP.')
    try:
        source_bytes = base64.b64decode(request['sourceZipBase64'], validate=True)
    except (ValueError, binascii.Error):
        raise ValueError('The captured source ZIP is not valid base64.') from None
    if not 0 < len(source_bytes) <= 12 * 1024 * 1024:
        raise ValueError('The captured source ZIP exceeds 12 MiB.')
    source_hash = hashlib.sha256(source_bytes).hexdigest()
    with tempfile.TemporaryDirectory(prefix='hardware-studio-project-cad-') as temporary:
        root = Path(temporary)
        source, output = root/'source.zip', root/'project-cad.zip'
        source.write_bytes(source_bytes)
        result = run_assembly_process([sys.executable, str(PROJECT_GENERATOR), '--worker', '--source-zip', str(source), '--out', str(output)], timeout=480)
        if result.returncode:
            message = 'The captured project could not be packaged. Every included CAD branch must build and pass its readback; no partial package was returned.'
            try:
                error = json.loads(result.stderr.strip().splitlines()[-1]).get('error')
                if isinstance(error, str) and error:
                    message = error[:1000]
            except (ValueError, AttributeError, IndexError):
                pass
            raise ValueError(message)
        if not output.is_file() or not 0 < output.stat().st_size <= 64 * 1024 * 1024:
            raise ValueError('The project CAD package is missing or exceeds 64 MiB.')
        with zipfile.ZipFile(output) as archive:
            manifest = json.loads(archive.read('cad-package-manifest.json'))
        if manifest.get('source_archive_sha256') != source_hash or manifest.get('status') not in ('passed', 'interference'):
            raise ValueError('The project CAD manifest does not match the captured source ZIP.')
        return output.read_bytes(), source_hash, manifest['status']


def generate_assembly_package(raw, preview=False):
    """Generate explicit, unfused placements with fresh-process readback."""
    with tempfile.TemporaryDirectory(prefix='hardware-studio-assembly-') as temporary:
        root = Path(temporary)
        source = root / 'input.json'
        source.write_bytes(raw)
        package = root / 'package'
        result = run_assembly_process([sys.executable, str(ASSEMBLY_GENERATOR), '--spec', str(source), '--out', str(package)])
        if result.returncode:
            raise ValueError('Assembly generation rejected the input or a geometry/readback check. Use valid solid assets, unique IDs and explicit bounded placements.')
        if preview:
            spec = json.loads((package / 'spec.json').read_text())
            report = json.loads((package / 'verification.json').read_text())
            instances = report['instances']
            names = [package / 'instances' / item['name'] for item in instances]
            if len(names) > 16 or sum(path.stat().st_size for path in names) > 16_000_000 or sum(item['stl_triangles'] for item in instances) > 400_000:
                raise ValueError('The assembly meshes exceed the browser preview limits.')
            return {'schema': 'hardware-studio-assembly-preview-v1', 'spec': spec, 'verification': report,
                    'meshes': [{'name': item['name'], 'id': item['id'], 'partId': item['partId'],
                                'dataBase64': base64.b64encode(path.read_bytes()).decode('ascii')}
                               for item, path in zip(instances, names)]}
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipped:
            for path in sorted(package.rglob('*')):
                if path.is_file():
                    zipped.write(path, arcname=path.relative_to(package).as_posix())
        return archive.getvalue()


def check_fit_request(raw):
    """Generate the submitted tray and compare bounded, caller-supplied STEP files."""
    request = json.loads(raw)
    if not isinstance(request, dict) or request.get('schema') != 'hardware-studio-browser-fit-v1':
        raise ValueError('Expected a hardware-studio-browser-fit-v1 request.')
    spec = request.get('traySpec')
    components = request.get('components')
    if not isinstance(spec, dict) or spec.get('schema') != 'hardware-studio-tray-v1':
        raise ValueError('Choose a valid tray spec.')
    if not isinstance(components, list) or not 1 <= len(components) <= 4:
        raise ValueError('Choose one to four STEP files.')
    with tempfile.TemporaryDirectory(prefix='hardware-studio-fit-') as temporary:
        root = Path(temporary)
        source = root / 'input.json'
        source.write_text(json.dumps(spec))
        package = root / 'package'
        generated = subprocess.run([sys.executable, str(GENERATOR), '--spec', str(source), '--out', str(package)],
                                   capture_output=True, text=True, timeout=120)
        if generated.returncode:
            raise ValueError('The CAD generator rejected this tray geometry.')
        manifest_components = []
        for index, item in enumerate(components):
            if not isinstance(item, dict) or not isinstance(item.get('dataBase64'), str):
                raise ValueError(f'Component {index + 1} needs a STEP file.')
            try:
                step_bytes = base64.b64decode(item['dataBase64'], validate=True)
            except (binascii.Error, ValueError):
                raise ValueError(f'Component {index + 1} is not valid base64.') from None
            if not 0 < len(step_bytes) <= MAX_STEP_BYTES:
                raise ValueError(f'Component {index + 1} must be under 8 MB.')
            filename = f'component-{index + 1}.step'
            (root / filename).write_bytes(step_bytes)
            manifest_components.append({'id': item.get('id'), 'step': filename,
                                        'translationMm': item.get('translationMm'),
                                        'rotation': item.get('rotation')})
        manifest = root / 'manifest.json'
        manifest.write_text(json.dumps({'schema': 'hardware-studio-fit-v1', 'trayPackage': 'package',
                                        'components': manifest_components, 'overlapLimitMm3': 0.01}))
        result = subprocess.run([sys.executable, str(FIT), '--manifest', str(manifest), '--out', str(root / 'report')],
                                capture_output=True, text=True, timeout=120)
        if result.returncode:
            raise ValueError('Fit analysis rejected a model or placement. Check STEP solids and axis settings.')
        report = json.loads((root / 'report' / 'fit-report.json').read_text())
        report.pop('manifest_sha256', None)  # The temporary manifest contains ephemeral local paths.
        return report


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _local_origin(self):
        host = self.headers.get('Host', '')
        allowed = {f'127.0.0.1:{self.server.server_port}', f'localhost:{self.server.server_port}'}
        if host not in allowed:
            return None
        origin = self.headers.get('Origin')
        if origin and origin not in {f'http://{item}' for item in allowed}:
            return None
        if self.headers.get('Sec-Fetch-Site', 'same-origin') not in ('same-origin', 'none'):
            return None
        return host

    def _json(self, code, payload):
        body = json.dumps(payload).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._local_origin():
            return self._json(403, {'error': 'Local origin required.'})
        path = urlsplit(self.path).path
        if path == '/api/health':
            return self._json(200, {'ok': True, 'cad': 'OpenCascade', 'units': 'mm', 'schema': 'hardware-studio-tray-v1', 'features': ['tray-preview-v1', 'feature-solid-v1', 'profile-solid-v1', 'placed-assembly-v1', 'sampled-mesh-readback-v1', 'project-cad-package-v1'] + (['curved-solid-v1'] if CURVED_RUNTIME else [])})
        if path.startswith('/api/'):
            return self._json(404, {'error': 'Unknown API route.'})
        return super().do_GET()

    def do_HEAD(self):
        if not self._local_origin():
            return self.send_error(403, 'Local origin required.')
        return super().do_HEAD()

    def list_directory(self, path):
        self.send_error(403, 'Directory listing disabled.')
        return None

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in ('/api/tray', '/api/tray-preview', '/api/fit', '/api/solid', '/api/solid-preview', '/api/assembly', '/api/assembly-preview', '/api/project-cad'):
            return self._json(404, {'error': 'Unknown API route.'})
        if not self._local_origin():
            return self._json(403, {'error': 'Local origin required.'})
        if self.headers.get('Content-Type', '').split(';', 1)[0].strip().lower() != 'application/json':
            return self._json(415, {'error': 'Send application/json.'})
        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            return self._json(400, {'error': 'Invalid request length.'})
        limit = MAX_PROJECT_REQUEST_BYTES if path == '/api/project-cad' else MAX_FIT_REQUEST_BYTES if path == '/api/fit' else MAX_ASSEMBLY_REQUEST_BYTES if path.startswith('/api/assembly') else MAX_REQUEST_BYTES
        if not 0 < length <= limit:
            return self._json(413, {'error': 'The request is too large.'})
        raw = self.rfile.read(length)
        if len(raw) != length:
            return self._json(400, {'error': 'Incomplete request.'})
        try:
            spec = json.loads(raw)
            expected = 'hardware-studio-project-cad-v1' if path == '/api/project-cad' else 'hardware-studio-browser-fit-v1' if path == '/api/fit' else 'hardware-studio-assembly-v1' if path.startswith('/api/assembly') else 'hardware-studio-solid-v1' if path.startswith('/api/solid') else 'hardware-studio-tray-v1'
            if not isinstance(spec, dict) or spec.get('schema') != expected:
                return self._json(400, {'error': f'Expected a {expected} request.'})
        except (UnicodeDecodeError, ValueError, RecursionError):
            return self._json(400, {'error': 'Invalid JSON.'})
        if not build_lock.acquire(blocking=False):
            return self._json(409, {'error': 'Another CAD build is running. Try again after it finishes.'})
        try:
            try:
                package_hash, package_status = None, None
                if path == '/api/project-cad':
                    output, package_hash, package_status = generate_project_package(raw)
                else:
                    output = check_fit_request(raw) if path == '/api/fit' else generate_assembly_package(raw, preview=path.endswith('-preview')) if path.startswith('/api/assembly') else generate_solid_package(raw, preview=path.endswith('-preview')) if path.startswith('/api/solid') else generate_package(raw, preview=path == '/api/tray-preview')
            except subprocess.TimeoutExpired:
                return self._json(504, {'error': 'Project CAD packaging exceeded eight minutes; no package was returned.' if path == '/api/project-cad' else 'Assembly generation exceeded three minutes.' if path.startswith('/api/assembly') else 'CAD generation exceeded two minutes.'})
            except ValueError as error:
                return self._json(422, {'error': str(error)})
            except Exception:
                return self._json(500, {'error': 'CAD generation failed. Inspect the local server terminal.'})
        finally:
            build_lock.release()
        try:
            is_archive = path in ('/api/tray', '/api/solid', '/api/assembly', '/api/project-cad')
            body = output if is_archive else json.dumps(output).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip' if is_archive else 'application/json; charset=utf-8')
            if is_archive:
                self.send_header('Content-Disposition', 'attachment; filename="hardware-studio-cad.zip"')
            if path == '/api/project-cad':
                self.send_header('X-Hardware-Studio-Source-SHA256', package_hash)
                self.send_header('X-Hardware-Studio-CAD-Status', package_status)
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port', type=int, default=4174)
    args = parser.parse_args()
    if not 0 <= args.port <= 65535:
        parser.error('Port must be 0 through 65535')
    server = ThreadingHTTPServer(('127.0.0.1', args.port), Handler)
    print(f'Hardware Studio CAD server: http://127.0.0.1:{server.server_port}/', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
