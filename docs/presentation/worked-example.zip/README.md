# Hardware Studio: one captured source and a nominal placement control

This archive contains actual synthetic project/source/CAD downloads, stored readbacks and an independently written inspector. It does not include the browser app, an installed agent host, models or a CAD library.

Python standard-library reader (no geometry reopening):
    python3 -B check.py

Existing OCP-enabled Python reader (direct fresh STEP volume/distance/overlap):
    /path/to/ocp-python -B check.py --cad

The source run used the repository-documented legacy fallback: Python 3.12.14, OCP 8.0.1.1.0, SymPy 1.14.0, without build123d. It demonstrates simple boxes and rigid placement only. Curves/fillets and other platforms require their own verified prerequisites. No install or global setup is performed by these commands.

With Node, run the exact bundled skill structural checker on both projects:
    node native/skill/scripts/check-project.mjs captured-project.json
    node native/skill/scripts/check-project.mjs control-project.json

Both pass structure. The actual browser captured two 10×8×4 mm boxes at x=0 and 13 mm: nominal gap 3 mm. The separate standalone control places B at 9 mm and reports 32 mm³ overlap/INTERFERENCE. Neither result validates physical fit, fabrication, electrical safety or a build procedure. Review marks remain false.

With the existing matching OCP Python, rebuild the captured source using only the included trusted compiler modules:
    /path/to/ocp-python -B native/tools/project-generator/project.py --source-zip /absolute/path/to/captured-source.zip --out /absolute/path/to/NEW-ABSENT.zip

The output parent must exist and destination must be absent. No supplied code, model or URL executes. Generated STEP headers/timings can differ; compare exact source capture identity, nominal geometry and status. This is not a general runtime/install acceptance claim.

checked-cad.zip is the actual 24-member browser download with 23 hashed payloads. Its nested captured-source.zip is also present separately: 11 exact original entries. control-cad.zip packages the actual separate assembly-generator output directory; it is not another browser project-CAD export. later-project.json is the later browser notes edit and does not update the earlier completed package. case.json, cad-manifest.json, cad-readback.json, control-readback.json and independent-readback.json retain the distinct evidence. The two source-derived figures are nominal top views; workspace PNGs are real app captures. MANIFEST.json hashes every payload and excludes itself.

Full app, skill instructions, runtime and compiler contracts remain external to this subset:
https://github.com/nazeeh111/hardware-studio-skill/tree/c649cc9b9ee84b8b667aa0fa26984d1d7746bc9d
Code MIT; LICENSE is included. No hardware, model call, account or physical trial occurred.
