# Instrument plate / first-part trial

Exported from Hardware Studio on 2026-10-23T23:17:18.114Z.

- [Project data](project.json): edit or re-import this JSON. Imported verification marks reset.
- [Parts list](bill-of-materials.csv): planning estimates; blank costs mean unknown.
- [Build plan](build-plan.txt): tools, assumptions and part-linked checklist; verify each operation.
- [Mounting notes](mounting.csv): proposed mechanical relationships, not verified fit.
- [Connection register](connections.csv): each recorded relationship and its pin-name review state; rows may still combine conductors.
- [Wiring map](wiring.svg): conceptual relationships, not a verified schematic.
- [Assembly index](assembly.svg): conceptual part inventory, not dimensioned CAD.
- [Open checks](review.txt): current editor findings.
- [Feature CAD input](solid-spec.json): ordered editable part source; generate checked STEP/STL separately in the solid modeler.

External evidence links remain URLs in project.json; their contents are not copied into this package.

Check exact parts, pinouts, power, fit and supplier listings before buying or building.
